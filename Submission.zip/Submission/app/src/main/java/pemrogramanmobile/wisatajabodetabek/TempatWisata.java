package pemrogramanmobile.wisatajabodetabek;

public class TempatWisata {
    private String objekwisata_name;
    private String lokasi;
    private String detailphoto;

    public String getObjekwisata_name() {
        return objekwisata_name;
    }

    public void setObjekwisata_name(String objekwisata_name) {
        this.objekwisata_name = objekwisata_name;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getDetailphoto() {
        return detailphoto;
    }

    public void setDetailphoto(String detailphoto) {
        this.detailphoto = detailphoto;
    }
}
