package pemrogramanmobile.wisatajabodetabek;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvHeroes;
    private ArrayList<TempatWisata> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvHeroes = findViewById(R.id.rv_objekwisata);
        rvHeroes.setHasFixedSize(true);

        list.addAll(TempatWisataDetail.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rvHeroes.setLayoutManager(new LinearLayoutManager(this));
        ListObjekWisataAdapter listObjekWisataAdapter = new ListObjekWisataAdapter(list);
        rvHeroes.setAdapter(listObjekWisataAdapter);
    }
}
